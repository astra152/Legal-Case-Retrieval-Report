#!/usr/bin/env python3
"""
案例文件解析脚本
支持从docx、pdf、txt文件中提取案件结构化信息

必填基础信息（6个）：
1. case_name - 完整案例名称
2. court - 裁判法院
3. trial_stage - 审判阶段（一审/二审/再审/执行）
4. doc_type - 文书类型（判决书/裁定书/调解书/决定书）
5. judgment_date - 裁判日期
6. case_number - 案号（最重要）

扩展信息：
- region - 省份（从法院名称提取）
- cause - 案由
- dispute_points - 争议焦点
- court_opinion - 法院认定
- judgment - 判决结果
- language - 语言（zh/en）

用法:
    python extract_cases.py --file <文件路径>
    python extract_cases.py --dir <文件夹路径>
    python extract_cases.py --file case1.docx --file case2.pdf --output result.json
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any

# 尝试导入依赖库
try:
    from docx import Document
except ImportError:
    Document = None

try:
    import fitz
except ImportError:
    fitz = None


# 省份映射表
PROVINCE_MAP = {
    "北京": "北京", "北京市": "北京",
    "上海": "上海", "上海市": "上海",
    "天津": "天津", "天津市": "天津",
    "重庆": "重庆", "重庆市": "重庆",
    "广东": "广东", "广东省": "广东", "广州": "广东", "深圳市": "广东", "深圳": "广东",
    "浙江": "浙江", "浙江省": "浙江", "杭州": "浙江", "宁波": "浙江", "温州": "浙江",
    "江苏": "江苏", "江苏省": "江苏", "南京": "江苏", "苏州": "江苏", "无锡": "江苏",
    "四川": "四川", "四川省": "四川", "成都": "四川",
    "湖北": "湖北", "湖北省": "湖北", "武汉": "湖北",
    "湖南": "湖南", "湖南省": "湖南", "长沙": "湖南",
    "河南": "河南", "河南省": "河南", "郑州": "河南",
    "河北": "河北", "河北省": "河北", "石家庄": "河北",
    "山东": "山东", "山东省": "山东", "济南": "山东", "青岛": "山东",
    "福建": "福建", "福建省": "福建", "福州": "福建", "厦门": "福建",
    "安徽": "安徽", "安徽省": "安徽", "合肥": "安徽",
    "陕西": "陕西", "陕西省": "陕西", "西安": "陕西",
    "辽宁": "辽宁", "辽宁省": "辽宁", "沈阳": "辽宁", "大连": "辽宁",
    "吉林": "吉林", "吉林省": "吉林", "长春": "吉林",
    "黑龙江": "黑龙江", "黑龙江省": "黑龙江", "哈尔滨": "黑龙江",
    "江西": "江西", "江西省": "江西", "南昌": "江西",
    "云南": "云南", "云南省": "云南", "昆明": "云南",
    "贵州": "贵州", "贵州省": "贵州", "贵阳": "贵州",
    "山西": "山西", "山西省": "山西", "太原": "山西",
    "内蒙古": "内蒙古", "内蒙古自治区": "内蒙古",
    "广西": "广西", "广西壮族自治区": "广西", "南宁": "广西", "桂林": "广西",
    "海南": "海南", "海南省": "海南", "海口": "海南", "三亚": "海南",
    "甘肃": "甘肃", "甘肃省": "甘肃", "兰州": "甘肃",
    "青海": "青海", "青海省": "青海", "西宁": "青海",
    "宁夏": "宁夏", "宁夏回族自治区": "宁夏", "银川": "宁夏",
    "新疆": "新疆", "新疆维吾尔自治区": "新疆", "乌鲁木齐": "新疆",
    "西藏": "西藏", "西藏自治区": "西藏", "拉萨": "西藏",
    "香港": "香港", "澳门": "澳门", "台湾": "台湾",
    "最高人民法院": "最高法",
}


class CaseExtractor:
    """案例信息提取器 - 严格提取6个基础信息字段"""
    
    # 6个必填基础信息字段
    REQUIRED_FIELDS = [
        "case_name",       # 完整案例名称
        "court",            # 裁判法院
        "trial_stage",      # 审判阶段
        "doc_type",         # 文书类型
        "judgment_date",     # 裁判日期
        "case_number"       # 案号
    ]
    
    # 文书类型枚举
    DOC_TYPES = [
        "判决书", "裁定书", "调解书", "决定书", 
        "判决", "裁定", "调解", "决定"
    ]
    
    # 审判阶段枚举
    TRIAL_STAGES = [
        "一审", "初审", "第一审", "二审", "终审", "第二审",
        "再审", "申诉", "执行", "财产保全", "先予执行",
        "重审", "发回重审"
    ]
    
    def __init__(self):
        self.cases: List[Dict[str, Any]] = []
        
    def extract_from_docx(self, file_path: str) -> List[Dict[str, Any]]:
        """从Word文档提取案例信息"""
        if Document is None:
            raise ImportError("python-docx未安装，请运行: pip install python-docx")
        
        cases = []
        doc = Document(file_path)
        
        # 提取所有段落文本
        full_text = "\n".join([p.text for p in doc.paragraphs])
        
        # 尝试从表格中提取结构化信息
        tables_data = []
        for table in doc.tables:
            table_text = []
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells]
                table_text.append(" | ".join(row_text))
            tables_data.append("\n".join(table_text))
        
        # 识别案例（基于案号格式）
        case_blocks = self._split_by_case_markers(full_text)
        
        for block in case_blocks:
            case_info = self._parse_case_block(block, tables_data, file_path)
            if case_info:
                cases.append(case_info)
        
        # 如果没有识别到案例，尝试整体解析
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, tables_data, file_path)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def extract_from_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        """从PDF提取案例信息"""
        if fitz is None:
            raise ImportError("pymupdf未安装，请运行: pip install pymupdf")
        
        cases = []
        doc = fitz.open(file_path)
        
        full_text = ""
        for page in doc:
            full_text += page.get_text() + "\n"
        
        # 检测语言
        language = self._detect_language(full_text)
        
        # 识别案例
        case_blocks = self._split_by_case_markers(full_text)
        
        for block in case_blocks:
            case_info = self._parse_case_block(block, [], file_path, language)
            if case_info:
                cases.append(case_info)
        
        # 如果没有识别到案例，尝试整体解析
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, [], file_path, language)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def extract_from_txt(self, file_path: str) -> List[Dict[str, Any]]:
        """从纯文本提取案例信息"""
        with open(file_path, 'r', encoding='utf-8') as f:
            full_text = f.read()
        
        # 检测语言
        language = self._detect_language(full_text)
        
        case_blocks = self._split_by_case_markers(full_text)
        cases = []
        
        for block in case_blocks:
            case_info = self._parse_case_block(block, [], file_path, language)
            if case_info:
                cases.append(case_info)
        
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, [], file_path, language)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def _detect_language(self, text: str) -> str:
        """检测文本语言"""
        # 简单检测：统计中文字符比例
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
        total_chars = len([c for c in text if c.isalpha()])
        
        if total_chars == 0:
            return "unknown"
        
        chinese_ratio = chinese_chars / total_chars
        if chinese_ratio > 0.3:
            return "zh"
        elif chinese_ratio < 0.1:
            return "en"
        else:
            return "mixed"
    
    def _split_by_case_markers(self, text: str) -> List[str]:
        """基于案号等标记分割文本为多个案例"""
        # 中文案号
        case_pattern_cn = r'([（\(]?\d{4}[）\)]\s*[\(（]?[民刑行商赔执访民]\s*\d{1,6}[\)）]?|[\u4e00-\u9fa5]{2}\s*\d{4}\s*[\u4e00-\u9fa5]{1,3}\s*\d{1,6}号)'
        # 英文案号
        case_pattern_en = r'(\d{1,2}:\s*\w{1,20}\s*(?:cv|Civ|Criminal|Case|CA|Dec)\s*\d{1,6}(?:\([^)]+\))?)'
        
        # 合并模式
        case_pattern = f'({case_pattern_cn}|{case_pattern_en})'
        
        parts = re.split(case_pattern, text)
        
        case_blocks = []
        current_block = ""
        
        for part in parts:
            if re.search(case_pattern, part):
                if current_block:
                    case_blocks.append(current_block.strip())
                current_block = part
            else:
                current_block += part
        
        if current_block.strip():
            case_blocks.append(current_block.strip())
        
        return case_blocks
    
    def _parse_case_block(self, block: str, tables_data: List[str] = None, source: str = None, language: str = "zh") -> Optional[Dict[str, Any]]:
        """解析单个案例块 - 严格提取6个基础信息"""
        if len(block) < 50:  # 内容太少，跳过
            return None
        
        case_info = {
            # 6个必填基础信息字段
            "case_name": self._extract_case_name(block, source),
            "court": self._extract_court(block),
            "trial_stage": self._extract_trial_stage(block),
            "doc_type": self._extract_doc_type(block),
            "judgment_date": self._extract_date(block),
            "case_number": self._extract_case_number(block),
            # 扩展信息
            "region": self._extract_region(self._extract_court(block)),
            "cause": self._extract_cause(block),
            "dispute_points": self._extract_dispute_points(block),
            "court_opinion": self._extract_court_opinion(block),
            "judgment": self._extract_judgment(block),
            "key_point": self._extract_key_point(block),
            "language": language,
            # 提取状态记录
            "_extraction_status": {
                "case_name": "found" if self._extract_case_name(block, source) else "missing",
                "court": "found" if self._extract_court(block) else "missing",
                "trial_stage": "found" if self._extract_trial_stage(block) else "missing",
                "doc_type": "found" if self._extract_doc_type(block) else "missing",
                "judgment_date": "found" if self._extract_date(block) else "missing",
                "case_number": "found" if self._extract_case_number(block) else "missing",
            }
        }
        
        # 只有在有基础信息时才返回
        if case_info["case_number"] or case_info["court_opinion"]:
            return case_info
        return None
    
    def _parse_document_as_single_case(self, text: str, tables_data: List[str], source: str, language: str = "zh") -> Optional[Dict[str, Any]]:
        """将整个文档解析为单个案例"""
        filename = os.path.basename(source) if source else "未知文件"
        
        case_info = {
            # 6个必填基础信息字段
            "case_name": self._extract_case_name(text, source) or self._extract_case_name_from_filename(filename),
            "court": self._extract_court(text),
            "trial_stage": self._extract_trial_stage(text),
            "doc_type": self._extract_doc_type(text),
            "judgment_date": self._extract_date(text),
            "case_number": self._extract_case_number(text) or self._extract_case_number_from_filename(filename),
            # 扩展信息
            "region": self._extract_region(self._extract_court(text)),
            "cause": self._extract_cause(text),
            "dispute_points": self._extract_dispute_points(text),
            "court_opinion": self._extract_court_opinion(text),
            "judgment": self._extract_judgment(text),
            "key_point": self._extract_key_point(text),
            "language": language,
            # 提取状态记录
            "_extraction_status": {
                "case_name": "found" if self._extract_case_name(text, source) else "missing",
                "court": "found" if self._extract_court(text) else "missing",
                "trial_stage": "found" if self._extract_trial_stage(text) else "missing",
                "doc_type": "found" if self._extract_doc_type(text) else "missing",
                "judgment_date": "found" if self._extract_date(text) else "missing",
                "case_number": "found" if self._extract_case_number(text) else "missing",
            }
        }
        
        return case_info if (case_info["case_number"] or case_info["court_opinion"]) else None
    
    # ========== 6个基础信息提取方法 ==========
    
    def _extract_case_name(self, text: str, source: str = None) -> Optional[str]:
        """提取完整案例名称"""
        patterns = [
            # 标题中的案例名称
            r'^#+\s*([^\n]{5,60}(?:案|纠纷|争议))',
            r'([^\n]{5,60}(?:案|纠纷|争议))\s*$',
            # 明确的案例名称格式
            r'案例名称[：:]\s*([^\n]{5,60})',
            r'案名[：:]\s*([^\n]{5,60})',
            r'案件名称[：:]\s*([^\n]{5,60})',
            # 常见格式：XXX与XXX XXX纠纷案
            r'([\u4e00-\u9fa5]{2,10}(?:与|和)\s*[\u4e00-\u9fa5]{2,10}\s*(?:的\s*)?(?:[\u4e00-\u9fa5]{0,10}(?:案|纠纷|争议|合同))?)',
            # 英文案例名
            r'((?:Smith|Jones|Johnson|Brown|Williams) v\.?\s*(?:Smith|Jones|Johnson|Brown|Williams)[^,\n]{0,50})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.MULTILINE)
            if match:
                name = match.group(1).strip()
                if len(name) >= 5:
                    return name
        
        return None
    
    def _extract_case_name_from_filename(self, filename: str) -> Optional[str]:
        """从文件名提取案例名称"""
        name = re.sub(r'\.(docx|pdf|txt)$', '', filename, flags=re.IGNORECASE)
        name = re.sub(r'[_\-]+', ' ', name)
        if len(name) >= 3:
            return name.strip()
        return None
    
    def _extract_court(self, text: str) -> Optional[str]:
        """提取裁判法院"""
        patterns = [
            # 完整法院名称
            r'([\u4e00-\u9fa5]{1,10}(?:中级人民法院|高级人民法院|最高人民法院|人民法院|区人民法院|县人民法院|市人民法院))',
            # 简化格式
            r'法院[：:]\s*([^\n]{2,25})',
            r'审理法院[：:]\s*([^\n]{2,25})',
            r'管辖法院[：:]\s*([^\n]{2,25})',
            r'裁判法院[：:]\s*([^\n]{2,25})',
            # 英文
            r'((?:Supreme Court|Superior Court|District Court|Court of Appeals|High Court)[^,\n]{0,30})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                court = match.group(1).strip()
                if len(court) >= 4:
                    return court
        return None
    
    def _extract_region(self, court: str) -> Optional[str]:
        """从法院名称提取省份"""
        if not court:
            return None
        
        for key, province in PROVINCE_MAP.items():
            if key in court:
                return province
        
        # 尝试匹配简称
        for key in PROVINCE_MAP.keys():
            if court.startswith(key) or key in court[:10]:
                return PROVINCE_MAP[key]
        
        return None
    
    def _extract_trial_stage(self, text: str) -> Optional[str]:
        """提取审判阶段"""
        for stage in self.TRIAL_STAGES:
            if stage in text:
                return stage
        
        patterns = [
            r'审判阶段[：:]\s*([^\n]{2,10})',
            r'审理程序[：:]\s*([^\n]{2,10})',
            r'((?:First|Second|Third)\s+(?:Instance|Trial|Appeal))',
            r'((?:初审|一审|二审|终审|再审|重审))',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        return None
    
    def _extract_doc_type(self, text: str) -> Optional[str]:
        """提取文书类型"""
        for doc_type in self.DOC_TYPES:
            if doc_type in text:
                return doc_type
        
        patterns = [
            r'文书类型[：:]\s*([^\n]{2,10})',
            r'((?:民事|刑事|行政|商事)?(?:判决书|裁定书|调解书|决定书))',
            r'((?:Judgment|Order|Decision| ruling|verdict))',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                doc_type = match.group(1).strip()
                if doc_type in ["判决", "裁定", "调解", "决定"]:
                    doc_type += "书"
                return doc_type
        
        return None
    
    def _extract_date(self, text: str) -> Optional[str]:
        """提取裁判日期"""
        patterns = [
            r'(\d{4})年(\d{1,2})月(\d{1,2})日',
            r'(\d{4})-(\d{2})-(\d{2})',
            r'(\d{4})\.(\d{2})\.(\d{2})',
            r'裁判日期[：:]\s*(\d{4}[年\-月\-日\.]{1,2}\d{1,2}[月日\-]{1,2}\d{1,2}日?)',
            r'判决日期[：:]\s*(\d{4}[年\-月\-日\.]{1,2}\d{1,2}[月日\-]{1,2}\d{1,2}日?)',
            # 英文日期
            r'((?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                if len(match.groups()) == 3:
                    year, month, day = match.groups()
                    return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
                else:
                    return match.group(1)
        return None
    
    def _extract_case_number(self, text: str) -> Optional[str]:
        """提取案号"""
        patterns = [
            # 中文案号
            r'[（\(]?(\d{4})[）\)]\s*[（\(]?([民刑行商赔执访民])[\u4e00-\u9fa5]?(\d{1,6})[）\)]?[号]?',
            # 省份+年份+类型+序号
            r'([\u4e00-\u9fa5]{2})\s*(\d{4})\s*[\u4e00-\u9fa5]{0,3}\s*(\d+)号',
            # 简化格式
            r'((?:20)?\d{2})[\u4e00-\u9fa5](?:民|刑|行|商|赔|执|访)[\u4e00-\u9fa5]?[\(（]?(\d{1,6})[\)）]?号?',
            # 案号标签
            r'案号[：:]\s*([^\n]{5,30})',
            # 英文案号
            r'((?:\d{1,2}:)?\w{1,20}\s*(?:cv|Civ|Criminal|Case|CA|Dec)\s*\d{1,6}(?:\([^)]+\))?)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(0).strip()
        return None
    
    def _extract_case_number_from_filename(self, filename: str) -> Optional[str]:
        """从文件名提取案号"""
        pattern = r'[\(（]?\d{4}[\)）]?\s*[\(（]?[民刑行商赔执访民][\u4e00-\u9fa5]?\d+[\)）]?号?'
        match = re.search(pattern, filename)
        if match:
            return match.group(0)
        return None
    
    # ========== 选填字段提取方法 ==========
    
    def _extract_cause(self, text: str) -> Optional[str]:
        """提取案由"""
        patterns = [
            r'案由[：:]\s*([^\n]{2,30})',
            r'案由[：:]\s*([\u4e00-\u9fa5]{2,10}(?:纠纷|案件|侵权|合同))',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        causes = ['合同纠纷', '侵权纠纷', '劳动争议', '离婚纠纷', '机动车交通事故', '民间借贷', 
                   '著作权权属', '著作权侵权', '商标权侵权', '专利权纠纷', '人格权纠纷',
                   '强奸罪', '诈骗罪', '盗窃罪', '抢劫罪']
        for cause in causes:
            if cause in text:
                return cause
        return None
    
    def _extract_dispute_points(self, text: str) -> List[str]:
        """提取争议焦点"""
        points = []
        
        dispute_section = re.search(r'争议焦点[：:\n]([^}]+?)(?:法院认为|裁判结果|审理认为|$)', text, re.DOTALL)
        if dispute_section:
            content = dispute_section.group(1)
            lines = [l.strip() for l in content.split('\n') if l.strip()]
            points = lines[:5]
        
        return points if points else []
    
    def _extract_court_opinion(self, text: str) -> Optional[str]:
        """提取法院认定"""
        patterns = [
            r'本院认为[：:]([^""]+?)(?:故|因此|综上|判决|$)',
            r'法院认定[：:]([^""]+?)(?:故|因此|综上|判决|$)',
            r'审理认为[：:]([^""]+?)(?:故|因此|综上|判决|$)',
            # 英文
            r'(?:The\s+court\s+(?:holds|finds|concludes|determines)[^.]+\.)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                opinion = match.group(1).strip()
                if len(opinion) > 20:
                    return opinion[:1000]
        
        return None
    
    def _extract_judgment(self, text: str) -> Optional[str]:
        """提取判决结果"""
        patterns = [
            r'判决[：:]([^""]+?)(?:如|如不服|$)',
            r'裁判结果[：:]([^""]+?)(?:如|如不服|$)',
            r'裁判主文[：:]([^""]+?)(?:如|如不服|$)',
            r'判决如下[：:：]([^}]{10,})',
            # 英文
            r'(?:Judgment\s+is\s+(?:hereby\s+)?(?:rendered|entered|granted)[^.]+\.)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
            if match:
                judgment = match.group(1).strip()
                if len(judgment) > 10:
                    return judgment[:500]
        
        return None
    
    def _extract_key_point(self, text: str) -> Optional[str]:
        """提取裁判要旨"""
        patterns = [
            r'要旨[：:]([^""]+?)[\n。]',
            r'裁判要旨[：:]([^""]+?)[\n。]',
            r'核心规则[：:]([^""]+?)[\n。]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                return match.group(1).strip()
        
        return None
    
    def extract_file(self, file_path: str) -> List[Dict[str, Any]]:
        """根据文件类型调用相应的提取方法"""
        ext = os.path.splitext(file_path)[1].lower()
        
        if ext == '.docx':
            return self.extract_from_docx(file_path)
        elif ext == '.pdf':
            return self.extract_from_pdf(file_path)
        elif ext == '.txt':
            return self.extract_from_txt(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {ext}")
    
    def extract_multiple(self, file_paths: List[str]) -> Dict[str, Any]:
        """提取多个文件"""
        all_cases = []
        errors = []
        
        for file_path in file_paths:
            try:
                cases = self.extract_file(file_path)
                all_cases.extend(cases)
            except Exception as e:
                errors.append({"file": file_path, "error": str(e)})
        
        # 生成统计信息
        stats = {
            "total_cases": len(all_cases),
            "case_name_found": sum(1 for c in all_cases if c.get("case_name")),
            "court_found": sum(1 for c in all_cases if c.get("court")),
            "trial_stage_found": sum(1 for c in all_cases if c.get("trial_stage")),
            "doc_type_found": sum(1 for c in all_cases if c.get("doc_type")),
            "judgment_date_found": sum(1 for c in all_cases if c.get("judgment_date")),
            "case_number_found": sum(1 for c in all_cases if c.get("case_number")),
            "region_distribution": self._count_regions(all_cases),
            "language_distribution": self._count_languages(all_cases),
        }
        
        return {
            "cases": all_cases,
            "metadata": {
                "total_files": len(file_paths),
                "total_cases": len(all_cases),
                "required_fields_stats": stats,
                "errors": errors
            }
        }
    
    def _count_regions(self, cases: List[Dict]) -> Dict[str, int]:
        """统计地区分布"""
        regions = {}
        for case in cases:
            region = case.get("region") or "未识别"
            regions[region] = regions.get(region, 0) + 1
        return regions
    
    def _count_languages(self, cases: List[Dict]) -> Dict[str, int]:
        """统计语言分布"""
        languages = {}
        for case in cases:
            lang = case.get("language", "unknown")
            languages[lang] = languages.get(lang, 0) + 1
        return languages


def main():
    parser = argparse.ArgumentParser(description='案例文件解析工具 - 严格提取6个基础信息字段')
    parser.add_argument('--file', '-f', action='append', help='单个文件路径')
    parser.add_argument('--dir', '-d', help='文件夹路径（将处理文件夹下所有支持的文件）')
    parser.add_argument('--output', '-o', help='输出JSON文件路径（可选）')
    
    args = parser.parse_args()
    
    file_paths = []
    
    if args.file:
        file_paths.extend(args.file)
    
    if args.dir:
        supported_ext = ['.docx', '.pdf', '.txt']
        for ext in supported_ext:
            file_paths.extend(Path(args.dir).glob(f'*{ext}'))
    
    if not file_paths:
        print(json.dumps({
            "error": "请提供文件路径，使用 --file 或 --dir 参数"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    file_paths = [str(fp) for fp in file_paths]
    
    extractor = CaseExtractor()
    result = extractor.extract_multiple(file_paths)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"结果已保存到: {args.output}")
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
