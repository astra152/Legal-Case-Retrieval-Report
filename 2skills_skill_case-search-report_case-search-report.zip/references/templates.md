# 模板与格式

## 目录

- [报告框架模板](#报告框架模板)
- [案例卡片模板](#案例卡片模板)
- [可视化图表模板](#可视化图表模板)
- [Mermaid流程图嵌入模板](#mermaid流程图嵌入模板)
- [矩阵模板](#矩阵模板)
- [渲染代码示例](#渲染代码示例)

---

## 报告框架模板

### 完整七段式模板

```markdown
# 案例分析报告

## 一、背景与问题

### 1.1 案件背景
[用户提供的背景 / 从案例综合提炼]

### 1.2 问题场景
基于上述背景，核心问题场景包括：
1. [场景A]
2. [场景B]
3. [场景C]

## 二、案件概况分析

### 2.1 基础信息总览
[6个必填字段汇总表]

### 2.2 地区分布与时间趋势
[柱状图+折线图复合图]

### 2.3 案由分布
[圆形图/饼图]

### 2.4 国内外案件（如涉及）
[国内外对比表]

## 三、争议焦点与裁判规则

### 3.1 核心问题场景
[问题场景拆分表]

### 3.2 争议焦点详细分析
[按焦点分配案例]

## 四、要件矩阵分析
（如可视化选型判断适用）

## 五、裁判流程图
（如可视化选型判断适用）

## 六、实务启示

[风险提示 + 操作建议]

## 七、总结

### 7.1 结论性判断
[直接回答用户问题]

### 7.2 实务建议
[可操作的具体建议]

### 7.3 缺失提示（如有）
<div style="color: red;">
[温馨提示]
</div>
```

---

## 案例卡片模板

### 完整案例卡片（含6个基础信息）

```markdown
## [序号] [案例名称]（案号：[case_number]）

### 基础信息

| 字段 | 内容 |
|------|------|
| 案例名称 | [case_name] |
| 裁判法院 | [court] |
| 审判阶段 | [trial_stage] |
| 文书类型 | [doc_type] |
| 裁判日期 | [judgment_date] |
| 案号 | [case_number] |

### 裁判结果
[支持/不支持/部分支持]

### 法院认定
> "[court_opinion]"

### 裁判要旨
[key_point]
```

### 无案号标注

```markdown
## [序号] [案例名称]（无案号/请填写案例来源）

### 基础信息

| 字段 | 内容 |
|------|------|
| 案例名称 | 未提供 |
| 裁判法院 | [court] |
| 审判阶段 | [trial_stage] |
| 文书类型 | [doc_type] |
| 裁判日期 | [judgment_date] |
| 案号 | 无案号/请填写案例来源 |
```

---

## 可视化图表模板

### 地区分布+时间趋势（柱状图+折线图复合图）

**数据格式**：

| 省份 | 2022年 | 2023年 | 2024年 | 合计 |
|------|--------|--------|--------|------|
| 北京 | 3 | 5 | 2 | 10 |
| 广东 | 2 | 4 | 6 | 12 |
| 上海 | 1 | 3 | 4 | 8 |

**可视化示意**：

```
省份
 ↑
 │  ┌─┐
 │  │█│     ┌─曲线─┐
 │  │█│ ┌─┐ │     ┌┐
 │  │█│ │█│ │    ┌┴┐
 │  │█│ │█│ ┌┐┌┐│ │   ┌┐
 │  │█│ │█│┌┴┴┴┴┴┴┐┌┴┐
 └──────────────────────→ 时间
     北京  广东  上海
     
     █ = 柱状图(案件数量)
     ─ = 折线图(趋势)
```

### 案由分布（圆形图/饼图）

**数据格式**：

| 案由 | 数量 | 占比 |
|------|------|------|
| 著作权侵权 | 15 | 37.5% |
| 合同纠纷 | 12 | 30% |
| 人格权纠纷 | 8 | 20% |
| 其他 | 5 | 12.5% |

**可视化示意**：

```
      ┌──────────────┐
     ╱  著作权侵权   ╲  37.5%
    │    37.5%      │
    │   ┌──────┐    │
    │  ╱合同纠纷╲   │
    │ │  30%   │   │
    │ │┌────┐ │   │
    │ ││人格 │ │   │
    │ ││权纠 │ │20%│
    │ │└────┘ │   │
    │  ╲纷20%╱    │
    │    └────┘    │
    └──────────────┘
        其他12%
```

### 信息缺失时

```markdown
### 2.2 地区分布

| 省份 | 案件数量 | 占比 |
|------|---------|------|
| 暂未识别 | - | - |

**可视化**：
内容填写"暂未识别"
```

---

## Mermaid流程图嵌入模板

### 模板1：基础判断流程

**Mermaid代码**：

````markdown
```mermaid
flowchart TD
    START([开始]) --> Q1{条件1?}
    Q1 -->|是| Q2{条件2?}
    Q1 -->|否| A1[结论1]
    Q2 -->|是| A2[结论2]
    Q2 -->|否| A3[结论3]
    
    style START fill:#4472C4,color:#fff
    style A1 fill:#90EE90
    style A2 fill:#90EE90
    style A3 fill:#FFB6C1
```
````

**渲染代码**：

```python
# 保存Mermaid代码
mermaid_code = '''
flowchart TD
    START([开始]) --> Q1{条件1?}
    Q1 -->|是| Q2{条件2?}
    Q1 -->|否| A1[结论1]
    Q2 -->|是| A2[结论2]
    Q2 -->|否| A3[结论3]
    
    style START fill:#4472C4,color:#fff
    style A1 fill:#90EE90
    style A2 fill:#90EE90
    style A3 fill:#FFB6C1
'''

with open('flowchart.mmd', 'w', encoding='utf-8') as f:
    f.write(mermaid_code)

# 渲染为PNG
import subprocess
subprocess.run(['mmdc', '-i', 'flowchart.mmd', '-o', 'flowchart.png', 
                '-w', '1400', '-b', 'white'], check=True)

# 嵌入docx
from docx import Document
doc = Document()
doc.add_heading('五、裁判流程图', level=1)
doc.add_picture('flowchart.png', width=Inches(6.5))
```

### 模板2：复杂判断流程

**Mermaid代码**：

````markdown
```mermaid
flowchart TD
    START([开始]) --> Q1{基础关系存在?}
    Q1 -->|否| END1([否定结论])
    Q1 -->|是| Q2{核心要件具备?}
    Q2 -->|否| END2([否定结论])
    Q2 -->|是| Q3{形式要件满足?}
    Q3 -->|是| Q4{实质审查?}
    Q3 -->|否| Q5{可补救?}
    Q5 -->|是| END3([补救后认定])
    Q5 -->|否| END4([否定结论])
    Q4 -->|是| END5([个案认定])
    Q4 -->|否| Q6{有无特殊情形?}
    Q6 -->|是| END6([特殊处理])
    Q6 -->|否| END7([依标准认定])
    
    style START fill:#4472C4,color:#fff
    style END1 fill:#FFB6C1
    style END2 fill:#FFB6C1
    style END3 fill:#FFE4B5
    style END4 fill:#FFB6C1
    style END5 fill:#90EE90
    style END6 fill:#FFE4B5
    style END7 fill:#90EE90
```
````

### 模板3：并行判断合并

**Mermaid代码**：

````markdown
```mermaid
flowchart TD
    START([开始]) --> Q1{要件A?}
    START --> Q2{要件B?}
    START --> Q3{要件C?}
    
    Q1 -->|结果1| R{综合判断}
    Q2 -->|结果2| R
    Q3 -->|结果3| R
    
    R -->|A+B+C全具备| A[肯定结论]
    R -->|A+B具备| B[部分肯定]
    R -->|仅A具备| C[个案认定]
    R -->|全部不具备| D[否定结论]
    
    style START fill:#4472C4,color:#fff
    style A fill:#90EE90
    style B fill:#90EE90
    style C fill:#FFE4B5
    style D fill:#FFB6C1
```
````

### 模板4：职务侵占罪认定流程（完整示例）

**Mermaid代码**：

````markdown
```mermaid
flowchart TD
    A([开始：审查是否<br/>构成职务侵占罪]) --> B{行为人是否<br/>具有工作人员<br/>身份?}
    B -->|否| C[不构成<br/>职务侵占罪]
    B -->|是| D{是否利用<br/>职务上的<br/>便利?}
    D -->|否| E[不构成<br/>职务侵占罪]
    D -->|是| F{侵占的是否<br/>为本单位财物?}
    F -->|否| G[不构成<br/>职务侵占罪]
    F -->|是| H{行为人是否<br/>为公司股东?}
    H -->|否| I{是否具有<br/>非法占有目的?}
    H -->|是| J[股东身份<br/>不阻却<br/>犯罪认定]
    I -->|否| K[需进一步判断<br/>是否属于借用<br/>挪用等情形]
    I -->|是| L[构成<br/>职务侵占罪]
    
    style A fill:#4472C4,stroke:#2D5AA0,color:#fff
    style C fill:#FF6B6B,stroke:#C00000,color:#fff
    style E fill:#FF6B6B,stroke:#C00000,color:#fff
    style G fill:#FF6B6B,stroke:#C00000,color:#fff
    style L fill:#70AD47,stroke:#507E32,color:#fff
    style J fill:#FFE4B5,stroke:#D4A84B
    style K fill:#FFE4B5,stroke:#D4A84B
```
````

---

## 矩阵模板

### 要素组合矩阵

**要素定义表**：

| 代号 | 要素名称 | 法律定义 |
|-----|---------|---------|
| a | 担保合意 | 双方具有担保债务履行的意思表示 |
| b | 债权真实 | 存在真实有效的债权债务关系 |
| c | 清算条款 | 约定了清算程序或归属条款 |

**组合矩阵**：

| a | b | c | 裁判结果 | 典型案例 |
|---|---|---|---------|---------|
| 明确 | 真实 | 有 | 有效担保-清算型 | 案例1 |
| 明确 | 真实 | 无 | 有效担保-清算型（事后补正） | 案例2 |
| 推定 | 真实 | 有 | 有效担保 | 案例3 |
| 推定 | 真实 | 无 | 需具体分析 | 案例4 |
| 无 | - | - | 非让与担保 | 案例5 |

### 矩阵嵌入docx模板

```python
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

# 添加标题
doc.add_heading('四、要件矩阵分析', level=1)

# 添加要素定义表
doc.add_heading('4.1 要素定义', level=2)
table = doc.add_table(rows=4, cols=3)
table.style = 'Table Grid'

# 表头
hdr_cells = table.rows[0].cells
hdr_cells[0].text = '代号'
hdr_cells[1].text = '要素名称'
hdr_cells[2].text = '法律定义'
for cell in hdr_cells:
    cell.paragraphs[0].runs[0].bold = True

# 数据行
data = [
    ('a', '担保合意', '双方具有担保债务履行的意思表示'),
    ('b', '债权真实', '存在真实有效的债权债务关系'),
    ('c', '清算条款', '约定了清算程序或归属条款'),
]
for i, (code, name, definition) in enumerate(data, start=1):
    row_cells = table.rows[i].cells
    row_cells[0].text = code
    row_cells[1].text = name
    row_cells[2].text = definition

# 添加矩阵表
doc.add_heading('4.2 组合矩阵', level=2)
matrix_table = doc.add_table(rows=6, cols=5)
matrix_table.style = 'Table Grid'

# 表头
matrix_hdr = matrix_table.rows[0].cells
for i, header in enumerate(['a', 'b', 'c', '裁判结果', '典型案例']):
    matrix_hdr[i].text = header
    matrix_hdr[i].paragraphs[0].runs[0].bold = True

# 数据
matrix_data = [
    ('明确', '真实', '有', '有效担保-清算型', '案例1'),
    ('明确', '真实', '无', '有效担保（事后补正）', '案例2'),
    ('推定', '真实', '有', '有效担保', '案例3'),
    ('推定', '真实', '无', '需具体分析', '案例4'),
    ('无', '-', '-', '非让与担保', '案例5'),
]
for i, row_data in enumerate(matrix_data, start=1):
    for j, value in enumerate(row_data):
        matrix_table.rows[i].cells[j].text = value

doc.save('report.docx')
```

---

## 渲染代码示例

### 完整Mermaid渲染流程

```python
import subprocess
import os
from docx import Document
from docx.shared import Inches, Pt

def render_mermaid_to_png(mermaid_code: str, output_path: str) -> str:
    """
    渲染Mermaid代码为PNG图片
    
    Args:
        mermaid_code: Mermaid语法代码
        output_path: 输出PNG路径
    
    Returns:
        成功返回图片路径，失败返回None
    """
    # Step 1: 保存为.mmd文件
    mmd_path = output_path.replace('.png', '.mmd')
    with open(mmd_path, 'w', encoding='utf-8') as f:
        f.write(mermaid_code)
    
    # Step 2: 尝试使用mmdc渲染
    try:
        result = subprocess.run(
            ['mmdc', '-i', mmd_path, '-o', output_path, 
             '-w', '1400', '-b', 'white', '-s', '2'],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode == 0 and os.path.exists(output_path):
            print(f"✓ Mermaid渲染成功: {output_path}")
            return output_path
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    
    # Step 3: 尝试npx
    try:
        result = subprocess.run(
            ['npx', '-p', 'mermaid-cli', 'mmdc', 
             '-i', mmd_path, '-o', output_path],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode == 0 and os.path.exists(output_path):
            print(f"✓ Npx渲染成功: {output_path}")
            return output_path
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    
    # Step 4: 使用matplotlib备用方案
    print("⚠ Mermaid CLI不可用，使用matplotlib备用方案")
    return draw_fallback_flowchart(mermaid_code, output_path)


def draw_fallback_flowchart(mermaid_code: str, output_path: str) -> str:
    """
    使用matplotlib绘制流程图作为备选方案
    """
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyBboxPatch, Polygon
    import numpy as np
    
    # 解析Mermaid代码中的节点信息（简化版）
    # 实际使用时应该用正则或解析器提取节点
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    ax.set_xlim(0, 14)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # 示例：绘制简单流程图
    # 实际应该根据mermaid_code解析
    
    # 起始节点
    start_box = FancyBboxPatch((5.5, 8.5), 3, 1, 
                                boxstyle="round,pad=0.05,rounding_size=0.3",
                                facecolor='#4472C4', edgecolor='#2D5AA0', linewidth=2)
    ax.add_patch(start_box)
    ax.text(7, 9, '开始', ha='center', va='center', color='white', fontsize=14, fontweight='bold')
    
    # 判断节点（菱形）
    diamond = Polygon([(7, 6.5), (9, 7.5), (7, 8.5), (5, 7.5)], 
                      facecolor='#FFE4B5', edgecolor='#D4A84B', linewidth=2)
    ax.add_patch(diamond)
    ax.text(7, 7.5, '条件?', ha='center', va='center', fontsize=12)
    
    # 箭头
    ax.annotate('', xy=(7, 8.5), xytext=(7, 9),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.5))
    
    plt.savefig(output_path, dpi=150, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    plt.close()
    
    return output_path


def add_flowchart_to_docx(doc: Document, mermaid_code: str, title: str = '裁判流程图'):
    """
    将流程图直接添加到docx文档
    
    Args:
        doc: Document对象
        mermaid_code: Mermaid语法代码
        title: 图表标题
    """
    # 添加标题
    heading = doc.add_heading(title, level=1)
    heading.paragraph_format.space_after = Pt(12)
    
    # 渲染图片
    temp_png = 'temp_flowchart.png'
    img_path = render_mermaid_to_png(mermaid_code, temp_png)
    
    if img_path and os.path.exists(img_path):
        # 添加图片到文档（适应页面宽度）
        doc.add_picture(img_path, width=Inches(6.5))
        last_paragraph = doc.paragraphs[-1]
        last_paragraph.alignment = 1  # 居中
        last_paragraph.paragraph_format.space_after = Pt(12)
    else:
        # 渲染失败时添加代码块作为备选
        doc.add_paragraph('【流程图渲染失败，仅展示Mermaid代码】')
        doc.add_paragraph(mermaid_code)
    
    # 清理临时文件
    if os.path.exists(temp_png):
        os.remove(temp_png)
    if os.path.exists('temp_flowchart.mmd'):
        os.remove('temp_flowchart.mmd')


# 使用示例
if __name__ == '__main__':
    doc = Document()
    doc.add_heading('案例分析报告', level=0)
    
    # Mermaid流程图代码
    flowchart_code = '''
flowchart TD
    A([开始]) --> B{条件?}
    B -->|是| C[结论A]
    B -->|否| D[结论B]
    
    style A fill:#4472C4,color:#fff
    style C fill:#90EE90
    style D fill:#FFB6C1
'''
    
    # 添加流程图
    add_flowchart_to_docx(doc, flowchart_code, '裁判流程图')
    
    doc.save('案例分析报告.docx')
    print("✓ 报告生成完成: 案例分析报告.docx")
```

---

## 附录：常用颜色代码

| 颜色名 | 背景色 | 用途 |
|--------|--------|------|
| 蓝色 | #4472C4 | 开始节点 |
| 浅绿 | #90EE90 | 肯定结论 |
| 浅红 | #FFB6C1 | 否定结论 |
| 浅黄 | #FFE4B5 | 待定/个案 |
| 浅蓝 | #ADD8E6 | 信息节点 |
| 绿色 | #70AD47 | 肯定结论（深） |
| 浅绿底 | #E2F0D9 | 辅助说明 |
