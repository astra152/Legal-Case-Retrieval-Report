# 流程图设计指南

## 目录

- [设计原则](#设计原则)
- [可视化选型判断](#可视化选型判断)
- [Mermaid语法规范](#mermaid语法规范)
- [Mermaid渲染流程](#mermaid渲染流程)
- [Draw.io备选方案](#drawio备选方案)
- [竖版流程图模板](#竖版流程图模板)
- [矩阵图设计](#矩阵图设计)
- [常见错误](#常见错误)

---

## 设计原则

### 简洁性原则

| 正确 | 错误 |
|------|------|
| 仅包含核心裁判要素 | 列出所有旁枝细节 |
| 判断节点简洁明了 | 复杂的多层嵌套 |
| 2-5个主要分支 | 超过7个分支 |

### 必要性原则

每个进入流程图的要素必须回答：

```
该要素是否直接影响裁判结果？
├─ 是 → 加入流程图
└─ 否 → 不加入
```

### 分支合并原则

| 情况 | 处理方式 |
|------|---------|
| 多个分支最终走向相同结果 | 合并 |
| 分支路径不同 | 分开展示 |
| 判断后直接结束 | 标注终止状态 |

---

## 可视化选型判断

### 选型决策树

```
开始分析
    │
    ▼
案例分析完成
    │
    ▼
┌─────────────────────────────────────────┐
│         可视化选型判断（必做）            │
└─────────────────────────────────────────┘
    │
    ▼
判断1：是否需要流程图？
├─ 判断路径是否清晰可描述为条件链？
├─ 核心要素是否≤7个？
├─ 分支是否可穷尽？
└─ 适用条件全部满足 → 流程图适用
    │
    ▼
判断2：是否需要矩阵？
├─ 要素是否≥3个？
├─ 各要素组合是否影响裁判结果？
└─ 需要展示组合规律 → 矩阵适用
    │
    ▼
选型结论：
├─ 仅流程图
├─ 仅矩阵
├─ 两者都用
└─ 两者都不用
```

### 选型标准详解

#### 流程图适用条件

| 条件 | 说明 | 判断问题 |
|------|------|---------|
| 判断路径清晰 | 可用"如果...那么..."描述 | 无法描述 → 不适用 |
| 要素有限 | 核心要素≤7个 | 过多 → 拆分为多个图 |
| 分支可穷尽 | 所有可能情况都能覆盖 | 有遗漏 → 补充分支 |
| 顺序依赖 | 某判断依赖前序判断结果 | 无顺序 → 用矩阵 |

#### 流程图不适用场景

```
❌ 不适合流程图的情况：
- 多个要素平行判断，无固定顺序
- 要素间关系复杂，非线性
- 涉及概率或模糊判断
- 需要展示的是组合结果而非判断路径
```

#### 矩阵适用条件

| 条件 | 说明 | 判断问题 |
|------|------|---------|
| 要素≥3个 | 至少需要组合分析的价值 | 少于3个 → 直接描述 |
| 组合影响结果 | 不同组合产生不同裁判 | 组合无关 → 不适用 |
| 需发现规律 | 从组合中归纳裁判规则 | 无规律 → 逐个列举 |

#### 矩阵不适用场景

```
❌ 不适合矩阵的情况：
- 单一要素决定结果
- 所有组合结果相同
- 要素之间相互独立无组合关系
```

### 选型结果记录模板

```markdown
### 可视化选型判断

| 可视化类型 | 适用性 | 判断理由 |
|-----------|--------|---------|
| 流程图 | 适用/不适用 | [...] |
| 矩阵 | 适用/不适用 | [...] |

**最终选择**：[流程图/矩阵/两者/两者都不用]
```

---

## Mermaid语法规范

### 为什么优先使用Mermaid

1. **自动布局**：Mermaid自动计算节点位置，避免手动调整坐标
2. **解决重叠**：自动布局算法从根本上避免字体重叠
3. **语法简洁**：比Draw.io XML更易编写和维护
4. **渲染一致**：同一语法在不同环境下渲染效果一致

### 基础语法

```mermaid
flowchart TD
    A[开始] --> B{判断}
    B -->|是| C[结果1]
    B -->|否| D[结果2]
```

### 节点类型

| 类型 | 语法 | 形状 | 中文示例 |
|------|------|------|---------|
| 开始/结束 | `A([文字])` | 圆角矩形 | `A([开始：判断职务侵占罪])` |
| 判断 | `A{条件?}` | 菱形 | `A{是否利用职务便利?}` |
| 处理/步骤 | `A[文字]` | 矩形 | `A[构成职务侵占罪]` |
| 子流程 | `A[[子流程]]` | 双边框 | `A[[审查财务凭证]]` |
| 条件标签 | `-->|标签|` | 分支 | `-->|是|` 或 `-->` |
| 多行文字 | `A[[第一行\n第二行]]` | 换行 | 见下方示例 |

### 中文处理技巧

#### 技巧1：使用简短标签

```mermaid
flowchart TD
    A([开始]) --> B{具有工作人员\n身份?}
    B -->|否| C[不构成\n职务侵占]
    B -->|是| D{利用职务\n便利?}
```

#### 技巧2：节点ID使用英文字母，标签用中文

```mermaid
flowchart TD
    A([开始]) --> B{是否具有\n身份?}
    B -->|否| C[否定结论]
    B -->|是| D{是否利用\n便利?}
    D -->|是| E[继续判断...]
```

#### 技巧3：使用br换行符

```mermaid
flowchart TD
    A([开始]) --> B{行为人是否<br/>公司员工?}
    B -->|是| C{非法占有<br/>本单位财物?}
```

### 连接线

| 类型 | 语法 | 说明 |
|------|------|------|
| 普通箭头 | `-->` | 单向箭头 |
| 带标签 | `-->|标签|` | 分支标签 |
| 多个出向 | `A --> B --> C` | 链式连接 |
| 虚线 | `-.->` | 虚线箭头 |
| 双向 | `<-->` | 双向箭头 |

### 样式定义

```mermaid
flowchart TD
    A([开始]) --> B{判断}
    B -->|是| C[支持/肯定]
    B -->|否| D[否定/不支持]
    
    style A fill:#4472C4,stroke:#2D5AA0,color:#fff
    style C fill:#70AD47,stroke:#507E32,color:#fff
    style D fill:#FF6B6B,stroke:#C00000,color:#fff
```

### 常用颜色规范

| 含义 | 背景色 | 边框色 | 文字色 |
|------|--------|--------|--------|
| 开始节点 | #4472C4 | #2D5AA0 | #fff |
| 肯定结论 | #70AD47 | #507E32 | #fff |
| 否定结论 | #FF6B6B | #C00000 | #fff |
| 待定/个案 | #FFE4B5 | #D4A84B | - |
| 辅助说明 | #E2F0D9 | #548235 | - |

### 完整示例：职务侵占罪判断流程

```mermaid
flowchart TD
    A([开始：审查是否<br/>构成职务侵占罪]) --> B{行为人是否<br/>具有工作人员<br/>身份?}
    B -->|否| C[不构成<br/>职务侵占罪]
    B -->|是| D{是否利用<br/>职务上的<br/>便利?}
    D -->|否| E[不构成<br/>职务侵占罪]
    D -->|是| F{侵占的是否<br/>为本单位财物?}
    F -->|否| G[不构成<br/>职务侵占罪]
    F -->|是| H{行为人是否<br/>为公司股东?}
    H -->|否| I{是否具有<br/>非法占有目的?}
    H -->|是| J[股东身份<br/>不阻却<br/>犯罪认定]
    I -->|否| K[需进一步判断<br/>是否属于借用
    挪用等情形]
    I -->|是| L[构成<br/>职务侵占罪]
    
    style A fill:#4472C4,stroke:#2D5AA0,color:#fff
    style C fill:#FF6B6B,stroke:#C00000,color:#fff
    style E fill:#FF6B6B,stroke:#C00000,color:#fff
    style G fill:#FF6B6B,stroke:#C00000,color:#fff
    style L fill:#70AD47,stroke:#507E32,color:#fff
    style J fill:#FFE4B5,stroke:#D4A84B
    style K fill:#FFE4B5,stroke:#D4A84B
```

---

## Mermaid渲染流程

### 渲染方案优先级

```
优先级1：Mermaid CLI (mmdc) ← 推荐
    ↓ 不可用时
优先级2：Python mermaid-py库
    ↓ 不可用时
优先级3：Python matplotlib手动绘制
    ↓ 都不行时
优先级4：Draw.io XML作为最后备选
```

### 方案1：Mermaid CLI (mmdc) - 推荐

#### 安装

```bash
# npm安装
npm install -g mermaid-cli

# 或使用npx直接运行
npx -p mermaid-cli mmdc --version
```

#### 使用流程

**Step 1**: 编写Mermaid代码保存为.mmd文件

```mermaid
%% flowchart-criminal-procedure.mmd
flowchart TD
    A([开始]) --> B{条件?}
    B -->|是| C[结论A]
    B -->|否| D[结论B]
    
    style A fill:#4472C4,color:#fff
    style C fill:#70AD47,color:#fff
    style D fill:#FF6B6B,color:#fff
```

**Step 2**: 执行渲染命令

```bash
# 基本用法
mmdc -i input.mmd -o output.png -b white

# 指定宽度（建议1200-1600，中文需要较大宽度）
mmdc -i flowchart.mmd -o flowchart.png -w 1400 -b white

# 高清渲染
mmdc -i flowchart.mmd -o flowchart.png -w 1600 -b white -s 2
```

**Step 3**: 将PNG嵌入docx

```python
from docx import Document
from docx.shared import Inches

doc = Document()
doc.add_heading('裁判流程图', level=1)
doc.add_picture('flowchart.png', width=Inches(6.5))
doc.save('report.docx')
```

### 方案2：Python mermaid-py库

#### 安装

```bash
pip install mermaid
```

#### 使用流程

```python
import mermaid

# 生成图片
code = '''
flowchart TD
    A([开始]) --> B{判断?}
    B -->|是| C[结果]
    style A fill:#4472C4,color:#fff
'''

# 使用API渲染（如有可用API）
# 或生成.mmd文件后手动用其他工具渲染
with open('flowchart.mmd', 'w', encoding='utf-8') as f:
    f.write(code)
```

### 方案3：Python matplotlib手动绘制（备选）

当上述方案都不可用时，使用matplotlib绘制：

```python
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

def draw_flowchart():
    fig, ax = plt.subplots(1, 1, figsize=(12, 10))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')
    
    # 定义节点
    nodes = [
        {'id': 'A', 'text': '开始', 'x': 5, 'y': 9, 'type': 'start'},
        {'id': 'B', 'text': '条件A?', 'x': 5, 'y': 7, 'type': 'diamond'},
        {'id': 'C', 'text': '结论1', 'x': 2, 'y': 5, 'type': 'rect', 'color': '#70AD47'},
        {'id': 'D', 'text': '结论2', 'x': 8, 'y': 5, 'type': 'rect', 'color': '#FF6B6B'},
    ]
    
    # 绘制节点和连线...
    # （完整代码见 templates.md 中的 matplotlib 流程图模板）
    
    plt.savefig('flowchart.png', dpi=150, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    return 'flowchart.png'
```

### 渲染失败处理

```python
import subprocess
import os

def render_mermaid(mmd_path, output_path):
    """渲染Mermaid流程图"""
    
    # 方案1: mmdc
    try:
        result = subprocess.run(
            ['mmdc', '-i', mmd_path, '-o', output_path, '-w', '1400', '-b', 'white'],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and os.path.exists(output_path):
            return output_path
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    
    # 方案2: npx
    try:
        result = subprocess.run(
            ['npx', '-p', 'mermaid-cli', 'mmdc', '-i', mmd_path, '-o', output_path],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode == 0 and os.path.exists(output_path):
            return output_path
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    
    # 方案3: matplotlib备用
    print("警告: Mermaid CLI不可用，将使用matplotlib绘制流程图")
    return draw_fallback_flowchart(mmd_path, output_path)
```

---

## Draw.io备选方案

### 何时使用Draw.io

只有当Mermaid渲染方案全部失败时，才使用Draw.io作为备选方案。

### 节点尺寸规范（中文环境）

| 节点类型 | 最小宽度 | 最小高度 | 说明 |
|---------|---------|---------|------|
| 矩形（处理） | 200px | 80px | 中文每行6-8字 |
| 菱形（判断） | 220px | 120px | 中文判断条件较长 |
| 圆角矩形（起止） | 180px | 70px | 开始/结束节点 |
| 分支标签 | 60px | 40px | "是"/"否"标签 |

### 间距规范

| 间距类型 | 最小值 | 说明 |
|---------|--------|------|
| 水平间距 | 150px | 两节点中心间水平距离 |
| 垂直间距 | 120px | 两节点中心间垂直距离 |
| 连线与标签 | 30px | 分支标签与连线交叉点 |
| 节点与边框 | 50px | 最外层节点距画布边缘 |

### 字体规范

| 设置项 | 推荐值 | 说明 |
|-------|--------|------|
| 中文字体 | 微软雅黑/思源黑体 | 确保系统安装 |
| 字号 | 14-16px | 中文需要稍大字号 |
| 行高 | 1.5倍 | 多行文字需要足够行高 |

### XML导出格式

使用Draw.io时，导出为PNG而非XML，确保嵌入docx时图片完整：

```
导出设置：
- 格式：PNG
- 缩放：2x（高清）
- 背景：白色
- 裁剪：勾选
```

### Draw.io到docx嵌入

```python
from docx import Document
from docx.shared import Inches, Pt

doc = Document()

# 添加标题
heading = doc.add_heading('裁判流程图', level=1)
heading.paragraph_format.space_after = Pt(12)

# 添加图片（宽度适应页面）
doc.add_picture('flowchart.png', width=Inches(6.5))
last_para = doc.paragraphs[-1]
last_para.alignment = 1  # 居中

doc.save('report.docx')
```

---

## 竖版流程图模板

### 基础模板

```mermaid
flowchart TD
    START([开始]) --> Q1{条件1?}
    Q1 -->|是| Q2{条件2?}
    Q1 -->|否| A1[结论A]
    Q2 -->|是| A2[结论B]
    Q2 -->|否| A3[结论C]
    
    style START fill:#4472C4,color:#fff
    style A1 fill:#90EE90
    style A2 fill:#90EE90
    style A3 fill:#FFB6C1
```

### 两层判断模板

```mermaid
flowchart TD
    START([开始]) --> Q1{基础关系存在?}
    Q1 -->|否| END1([否定结论])
    Q1 -->|是| Q2{核心要件具备?}
    Q2 -->|否| END2([否定结论])
    Q2 -->|是| Q3{形式要件满足?}
    Q3 -->|是| END3([肯定结论])
    Q3 -->|否| Q4{实质审查?}
    Q4 -->|是| END4([个案认定])
    Q4 -->|否| END5([否定结论])
    
    style START fill:#4472C4,color:#fff
    style END1 fill:#FFB6C1
    style END2 fill:#FFB6C1
    style END3 fill:#90EE90
    style END4 fill:#FFE4B5
    style END5 fill:#FFB6C1
```

### 分类判断模板

```mermaid
flowchart TD
    START([开始]) --> Q1{类型A?}
    Q1 -->|是| A[结论A]
    Q1 -->|否| Q2{类型B?}
    Q2 -->|是| B[结论B]
    Q2 -->|否| C[结论C]
    
    style START fill:#4472C4,color:#fff
    style A fill:#ADD8E6
    style B fill:#ADD8E6
    style C fill:#ADD8E6
```

### 并行判断模板

```mermaid
flowchart TD
    START([开始]) --> Q1{要件1?}
    START --> Q2{要件2?}
    START --> Q3{要件3?}
    
    Q1 -->|是/否| R{综合判断}
    Q2 -->|是/否| R
    Q3 -->|是/否| R
    
    R -->|全部具备| A[肯定结论]
    R -->|部分具备| B[个案认定]
    R -->|全部不具备| C[否定结论]
    
    style START fill:#4472C4,color:#fff
    style A fill:#90EE90
    style B fill:#FFE4B5
    style C fill:#FFB6C1
```

---

## 矩阵图设计

### 设计步骤

```
第一步：识别所有潜在要素
         ↓
第二步：单要素筛选（是否影响裁判）
         ↓
第三步：核心要素配对
         ↓
第四步：构建矩阵
         ↓
第五步：填充结果
```

### 简化命名规则

| 情况 | 命名方式 | 示例 |
|------|---------|------|
| 要素名称≤4字 | 直接使用名称 | 担保合意、有独创性 |
| 要素名称>4字 | 使用代号 | a=担保合意、b=独创性 |

### 矩阵表模板

```markdown
## [主题]要件矩阵

| 代号 | 要素名称 | 法律定义 |
|-----|---------|---------|
| a | [名称] | [定义] |
| b | [名称] | [定义] |
| c | [名称] | [定义] |

### 要素组合矩阵

| a | b | c | 裁判结果 | 典型案例 |
|---|---|---|---------|---------|
| 具备 | 具备 | 具备 | 支持 | 案例1 |
| 具备 | 具备 | 不具备 | 部分支持 | 案例2 |
| 具备 | 不具备 | - | 不支持 | 案例3 |
```

### 筛选过程示例

**原始要素**：
- 担保合意
- 债权真实性
- 权利转移程度
- 清算条款
- 对价合理性

**第一轮筛选**（单要素）：

| 要素 | 是否影响结果 | 保留 |
|------|------------|-----|
| 担保合意 | 是 | 保留(a) |
| 债权真实性 | 是 | 保留(b) |
| 权利转移程度 | 部分 | 待定 |
| 清算条款 | 是 | 保留(c) |
| 对价合理性 | 否 | 剔除 |

**第二轮筛选**（配对）：

| 组合 | 裁判差异 | 结论 |
|------|---------|------|
| a+b | 差异明显 | 核心组合 |
| a+c | 差异明显 | 核心组合 |
| b+c | 差异不明显 | 可合并 |

**最终矩阵**：

```markdown
| a（担保合意） | b（债权真实） | c（清算条款） | 结果 |
|-------------|-------------|-------------|------|
| 明确 | 真实 | 有 | 有效担保 |
| 明确 | 真实 | 无 | 需进一步审查 |
| 推定 | 真实 | 有 | 有效担保 |
| 无 | - | - | 非担保 |
```

---

## 常见错误

### 错误1：要素过多

```
错误示例：10+个要素全部放入流程图
正确做法：筛选至3-5个核心要素
```

### 错误2：嵌套过深

```
错误示例：5层以上的条件嵌套
正确做法：最多3层，复杂逻辑用矩阵补充
```

### 错误3：分支不完整

```
错误示例：只有"是"的分支，没有"否"的分支
正确做法：每个判断节点都要有完整分支
```

### 错误4：结论不明确

```
错误示例：判断节点后直接进入下一个判断
正确做法：每个分支最终都要有明确的结论节点
```

### 错误5：颜色使用混乱

```
错误示例：随意使用颜色，无统一含义
正确做法：统一颜色含义（绿=支持/红=否定/黄=待定）
```

### 错误6：未进行选型判断

```
错误示例：直接默认使用流程图
正确做法：必须先进行选型判断并记录理由
```

### 错误7：流程图作为附件

```
错误示例：生成单独的drawio文件，说"详见附件"
正确做法：渲染为PNG后嵌入docx报告
```

---

## Mermaid图表位置

在Markdown中使用Mermaid图表：

````markdown
```mermaid
flowchart TD
    A([开始]) --> B{判断?}
    B -->|是| C[结论]
    style A fill:#4472C4,color:#fff
```
````
