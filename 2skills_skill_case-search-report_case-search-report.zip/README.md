# Case Search Report

> 专业的法律案例分析报告生成工具 | AI驱动的类案检索与裁判规则提炼

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)](SKILL.md)

## 功能特性

- 📁 **多格式支持** - 支持 Word (.docx)、PDF (.txt) 格式文件解析
- 🔍 **智能提取** - 自动识别案号、法院、裁判日期等核心信息
- 📊 **可视化分析** - 地区分布图、案由饼图、人物关系图
- 🌐 **多语言处理** - 支持中英文判决书，自动识别语言
- 🎯 **动态框架** - 根据案例特征自动适配最佳报告结构
- ⚖️ **裁判规则** - 流程图、要件矩阵、争议焦点分配

## 快速开始

### 1. 安装依赖

```bash
pip install python-docx pymupdf
```

### 2. 解析案例文件

```bash
# 解析单个文件
python scripts/extract_cases.py --file case.docx

# 解析文件夹下所有文件
python scripts/extract_cases.py --dir ./cases/

# 输出到JSON
python scripts/extract_cases.py --file case.docx --output result.json
```

### 3. 生成分析报告

1. 上传案例文件到智能体
2. 描述问题背景或研究目标
3. 智能体自动生成结构化报告

## 报告结构

报告根据案例特征动态适配以下组件：

| 组件 | 说明 |
|-----|------|
| 背景与场景 | 问题来源与研究价值 |
| 案例总体概况 | 可视化统计分析 |
| 基础信息汇总 | 6个必填字段表格 |
| 争议焦点分配 | 按问题分类案例 |
| 要件矩阵分析 | 多要素组合规律 |
| 裁判规则提炼 | 流程图/矩阵图 |
| 实务操作指引 | 合规建议与风险防控 |

## 必填信息字段

| 字段 | 说明 |
|-----|------|
| 案例名称 | 完整案例名称 |
| 裁判法院 | 审理案件的法院 |
| 审判阶段 | 一审/二审/再审/执行 |
| 文书类型 | 判决书/裁定书/调解书 |
| 裁判日期 | 判决时间 |
| 案号 | 唯一标识符（最重要） |

## 目录结构

```
case-search-report/
├── SKILL.md                      # 核心指南
├── scripts/
│   └── extract_cases.py          # 案例解析脚本
├── references/
│   ├── report-structure.md       # 报告结构规范
│   ├── case-analysis-methods.md  # 案例分析方法
│   ├── rule-extraction.md        # 规则提炼技术
│   ├── flowchart-guide.md        # 流程图绘制指南
│   └── templates.md              # 模板与格式
└── assets/
    └── case-matrix-template.xlsx # Excel分析模板
```

## 使用示例

### 输入
```
用户：分析股权让与担保中流质条款的效力认定
上传文件：case1.pdf, case2.docx, case3.txt
```

### 输出
```
1. 案例总体概况（含可视化图表）
2. 6个案例的基础信息汇总表
3. 核心争议焦点：流质条款 vs 清算义务
4. 案例分配：
   - 争议焦点A → 案例1、案例2
   - 争议焦点B → 案例3
5. 裁判规则流程图（mermaid格式）
6. 实务操作指引
```

## 设计原则

- **连贯性** - 报告逻辑前后衔接，层层递进
- **动态适配** - 根据案例特点选择最佳展示方式
- **信息完整** - 缺失信息标注，不捏造不遗漏
- **可视化优先** - 复杂规则用图表清晰呈现

## License

MIT License
