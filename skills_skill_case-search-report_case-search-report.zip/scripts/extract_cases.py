#!/usr/bin/env python3
"""
案例文件解析脚本
支持从docx、pdf、txt文件中提取案件结构化信息

用法:
    python extract_cases.py --file <文件路径>
    python extract_cases.py --dir <文件夹路径>
    python extract_cases.py --file case1.docx --file case2.pdf
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any

# 尝试导入依赖库
try:
    from docx import Document
except ImportError:
    Document = None

try:
    import fitz
except ImportError:
    fitz = None


class CaseExtractor:
    """案例信息提取器"""
    
    def __init__(self):
        self.cases: List[Dict[str, Any]] = []
        
    def extract_from_docx(self, file_path: str) -> List[Dict[str, Any]]:
        """从Word文档提取案例信息"""
        if Document is None:
            raise ImportError("python-docx未安装，请运行: pip install python-docx")
        
        cases = []
        doc = Document(file_path)
        
        # 提取所有段落文本
        full_text = "\n".join([p.text for p in doc.paragraphs])
        
        # 尝试从表格中提取结构化信息
        tables_data = []
        for table in doc.tables:
            table_text = []
            for row in table.rows:
                row_text = [cell.text.strip() for cell in row.cells]
                table_text.append(" | ".join(row_text))
            tables_data.append("\n".join(table_text))
        
        # 识别案例（基于案号格式）
        case_blocks = self._split_by_case_markers(full_text)
        
        for block in case_blocks:
            case_info = self._parse_case_block(block, tables_data)
            if case_info:
                cases.append(case_info)
        
        # 如果没有识别到案例，尝试整体解析
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, tables_data, file_path)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def extract_from_pdf(self, file_path: str) -> List[Dict[str, Any]]:
        """从PDF提取案例信息"""
        if fitz is None:
            raise ImportError("pymupdf未安装，请运行: pip install pymupdf")
        
        cases = []
        doc = fitz.open(file_path)
        
        full_text = ""
        for page in doc:
            full_text += page.get_text() + "\n"
        
        # 识别案例
        case_blocks = self._split_by_case_markers(full_text)
        
        for block in case_blocks:
            case_info = self._parse_case_block(block)
            if case_info:
                cases.append(case_info)
        
        # 如果没有识别到案例，尝试整体解析
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, [], file_path)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def extract_from_txt(self, file_path: str) -> List[Dict[str, Any]]:
        """从纯文本提取案例信息"""
        with open(file_path, 'r', encoding='utf-8') as f:
            full_text = f.read()
        
        case_blocks = self._split_by_case_markers(full_text)
        cases = []
        
        for block in case_blocks:
            case_info = self._parse_case_block(block)
            if case_info:
                cases.append(case_info)
        
        if not cases:
            case_info = self._parse_document_as_single_case(full_text, [], file_path)
            if case_info:
                cases.append(case_info)
        
        return cases
    
    def _split_by_case_markers(self, text: str) -> List[str]:
        """基于案号等标记分割文本为多个案例"""
        # 案号正则：年份+括号+类型+序号 或 省份简称+年份+类型+序号
        case_pattern = r'([（\(]?\d{4}[）\)]\s*[\(（]?[民刑行商赔执访民]\s*\d{1,6}[\)）]?|[\u4e00-\u9fa5]{2}\s*\d{4}\s*[\u4e00-\u9fa5]{1,3}\s*\d{1,6}号)'
        
        parts = re.split(case_pattern, text)
        
        case_blocks = []
        current_block = ""
        
        for part in parts:
            if re.search(case_pattern, part):
                if current_block:
                    case_blocks.append(current_block.strip())
                current_block = part
            else:
                current_block += part
        
        if current_block.strip():
            case_blocks.append(current_block.strip())
        
        return case_blocks
    
    def _parse_case_block(self, block: str, tables_data: List[str] = None) -> Optional[Dict[str, Any]]:
        """解析单个案例块"""
        if len(block) < 50:  # 内容太少，跳过
            return None
        
        case_info = {
            "case_number": self._extract_case_number(block),
            "court": self._extract_court(block),
            "date": self._extract_date(block),
            "cause": self._extract_cause(block),
            "dispute_points": self._extract_dispute_points(block),
            "court_opinion": self._extract_court_opinion(block),
            "judgment": self._extract_judgment(block),
            "key_point": self._extract_key_point(block),
            "raw_text": block[:500] if len(block) > 500 else block  # 保留原文用于校验
        }
        
        # 只有在有关键信息时才返回
        if case_info["case_number"] or case_info["court_opinion"]:
            return case_info
        return None
    
    def _parse_document_as_single_case(self, text: str, tables_data: List[str], source: str) -> Optional[Dict[str, Any]]:
        """将整个文档解析为单个案例"""
        filename = os.path.basename(source)
        
        case_info = {
            "case_number": self._extract_case_number(text) or filename.replace('.docx', '').replace('.pdf', '').replace('.txt', ''),
            "court": self._extract_court(text),
            "date": self._extract_date(text),
            "cause": self._extract_cause(text),
            "dispute_points": self._extract_dispute_points(text),
            "court_opinion": self._extract_court_opinion(text),
            "judgment": self._extract_judgment(text),
            "key_point": self._extract_key_point(text),
            "raw_text": text[:500] if len(text) > 500 else text
        }
        
        return case_info if case_info["court_opinion"] else None
    
    def _extract_case_number(self, text: str) -> Optional[str]:
        """提取案号"""
        patterns = [
            r'[\(（]?(\d{4})[\)）]\s*[\(（]?([民刑行商赔执访])\s*(\d{1,6})[\)）]?号',
            r'([\u4e00-\u9fa5]{2,})\s*(\d{4})\s*[\u4e00-\u9fa5]{1,3}\s*(\d+)号',
            r'((?:20)?\d{2})[\u4e00-\u9fa5](?:民|刑|行|商|赔|执|访)[\u4e00-\u9fa5]?[\(（]?(\d{1,6})[\)）]?号?'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(0)
        return None
    
    def _extract_court(self, text: str) -> Optional[str]:
        """提取法院"""
        patterns = [
            r'([\u4e00-\u9fa5]{1,10}(?:中级人民法院|高级人民法院|最高人民法院|人民法院|区人民法院|县人民法院|市人民法院))',
            r'法院[：:]\s*([^\n]{2,20})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                court = match.group(1).strip()
                if len(court) >= 4:
                    return court
        return None
    
    def _extract_date(self, text: str) -> Optional[str]:
        """提取裁判日期"""
        patterns = [
            r'(\d{4})年(\d{1,2})月(\d{1,2})日',
            r'(\d{4})-(\d{2})-(\d{2})',
            r'(\d{4})\.(\d{2})\.(\d{2})',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                if len(match.groups()) == 3:
                    return f"{match.group(1)}-{match.group(2).zfill(2)}-{match.group(3).zfill(2)}"
        return None
    
    def _extract_cause(self, text: str) -> Optional[str]:
        """提取案由"""
        patterns = [
            r'案由[：:]\s*([^\n]{2,30})',
            r'案由[：:]\s*([\u4e00-\u9fa5]{2,10}(?:纠纷|案件|侵权|合同))',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1).strip()
        
        # 常见案由关键词
        causes = ['合同纠纷', '侵权纠纷', '劳动争议', '离婚纠纷', '机动车交通事故', '民间借贷']
        for cause in causes:
            if cause in text:
                return cause
        return None
    
    def _extract_dispute_points(self, text: str) -> List[str]:
        """提取争议焦点"""
        points = []
        
        patterns = [
            r'争议焦点[：:]\s*([^\n]+)',
            r'本院认为[，,]([^。]+)',  # 简化的法院认为提取
        ]
        
        # 查找"争议焦点"相关段落
        dispute_section = re.search(r'争议焦点[：:\n]([^}]+?)(?:法院认为|裁判结果|$)', text, re.DOTALL)
        if dispute_section:
            content = dispute_section.group(1)
            lines = [l.strip() for l in content.split('\n') if l.strip()]
            points = lines[:5]  # 取前5条
        
        return points if points else []
    
    def _extract_court_opinion(self, text: str) -> Optional[str]:
        """提取法院认定"""
        patterns = [
            r'本院认为[：:]([^""]+?)(?:故|因此|综上|判决|$)',
            r'法院认定[：:]([^""]+?)(?:故|因此|综上|判决|$)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                opinion = match.group(1).strip()
                if len(opinion) > 20:
                    return opinion[:1000]  # 限制长度
        
        # 备用：提取包含"认为"的段落
        think_match = re.search(r'本院认为[：:]([^}]{100,})', text, re.DOTALL)
        if think_match:
            return think_match.group(1).strip()[:1000]
        
        return None
    
    def _extract_judgment(self, text: str) -> Optional[str]:
        """提取判决结果"""
        patterns = [
            r'判决[：:]([^""]+?)(?:如|如不服|$)',
            r'裁判结果[：:]([^""]+?)(?:如|如不服|$)',
            r'裁判主文[：:]([^""]+?)(?:如|如不服|$)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                judgment = match.group(1).strip()
                if len(judgment) > 10:
                    return judgment[:500]
        
        # 查找"判决如下"段落
        judgment_section = re.search(r'判决如下[：:：]([^}]{10,})', text, re.DOTALL)
        if judgment_section:
            return judgment_section.group(1).strip()[:500]
        
        return None
    
    def _extract_key_point(self, text: str) -> Optional[str]:
        """提取裁判要旨"""
        patterns = [
            r'要旨[：:]([^""]+?)[\n。]',
            r'裁判要旨[：:]([^""]+?)[\n。]',
            r'核心规则[：:]([^""]+?)[\n。]',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                return match.group(1).strip()
        
        return None
    
    def extract_file(self, file_path: str) -> List[Dict[str, Any]]:
        """根据文件类型调用相应的提取方法"""
        ext = os.path.splitext(file_path)[1].lower()
        
        if ext == '.docx':
            return self.extract_from_docx(file_path)
        elif ext == '.pdf':
            return self.extract_from_pdf(file_path)
        elif ext == '.txt':
            return self.extract_from_txt(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {ext}")
    
    def extract_multiple(self, file_paths: List[str]) -> Dict[str, Any]:
        """提取多个文件"""
        all_cases = []
        errors = []
        
        for file_path in file_paths:
            try:
                cases = self.extract_file(file_path)
                all_cases.extend(cases)
            except Exception as e:
                errors.append({"file": file_path, "error": str(e)})
        
        return {
            "cases": all_cases,
            "metadata": {
                "total_files": len(file_paths),
                "total_cases": len(all_cases),
                "errors": errors
            }
        }


def main():
    parser = argparse.ArgumentParser(description='案例文件解析工具')
    parser.add_argument('--file', '-f', action='append', help='单个文件路径')
    parser.add_argument('--dir', '-d', help='文件夹路径（将处理文件夹下所有支持的文件）')
    parser.add_argument('--output', '-o', help='输出JSON文件路径（可选）')
    
    args = parser.parse_args()
    
    file_paths = []
    
    if args.file:
        file_paths.extend(args.file)
    
    if args.dir:
        supported_ext = ['.docx', '.pdf', '.txt']
        for ext in supported_ext:
            file_paths.extend(Path(args.dir).glob(f'*{ext}'))
    
    if not file_paths:
        print(json.dumps({
            "error": "请提供文件路径，使用 --file 或 --dir 参数"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)
    
    # 转换为字符串路径
    file_paths = [str(fp) for fp in file_paths]
    
    # 执行提取
    extractor = CaseExtractor()
    result = extractor.extract_multiple(file_paths)
    
    # 输出结果
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"结果已保存到: {args.output}")
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
